import React from "react";
import ReactDOM from "react-dom/client";
import SkillEvaluator from "./SkillEvaluator";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <SkillEvaluator />
  </React.StrictMode>
);
